using System;
using System.Collections.Generic;
using System.Text;

namespace logistics
{
    public class GraphSettings
    {
        private string mFunction;
        private string mSlope;
        private string mDerivative;

        private int mGraph;

        private double mXMax;
        private double mXMin;
        private double mXIncr;

        private double mYMax;
        private double mYMin;
        private double mYIncr;

        private double mTraceLen;

        private double mSlopeColorLimit;

        private int mBaseR;
        private int mBaseG;
        private int mBaseB;

        public int Graph
        {
            get
            {
                return mGraph;
            }
            set
            {
                mGraph = value;
            }
        }

        public int BaseB
        {
            get
            {
                return mBaseB;
            }
            set
            {
                mBaseB = value;
            }
        }

        public int BaseG
        {
            get
            {
                return mBaseG;
            }
            set
            {
                mBaseG = value;
            }
        }

        public int BaseR
        {
            get
            {
                return mBaseR;
            }
            set
            {
                mBaseR = value;
            }
        }

        public double SlopeColorLimit
        {
            get
            {
                return mSlopeColorLimit;
            }
            set
            {
                mSlopeColorLimit = value;
            }
        }

        public double TraceLen
        {
            get
            {
                return mTraceLen;
            }
            set
            {
                mTraceLen = value;
            }
        }

        public string Function
        {
            get
            {
                return mFunction;
            }
            set
            {
                mFunction = value;
            }
        }

        public string Slope
        {
            get
            {
                return mSlope;
            }
            set
            {
                mSlope = value;
            }
        }

        public string Derivative
        {
            get
            {
                return mDerivative;
            }
            set
            {
                mDerivative = value;
            }
        }

        public double XMax
        {
            get
            {
                return mXMax;
            }
            set
            {
                mXMax = value;
            }
        }

        public double XMin
        {
            get
            {
                return mXMin;
            }
            set
            {
                mXMin = value;
            }
        }

        public double XIncr
        {
            get
            {
                return mXIncr;
            }
            set
            {
                mXIncr = value;
            }
        }

        public double YMax
        {
            get
            {
                return mYMax;
            }
            set
            {
                mYMax = value;
            }
        }

        public double YMin
        {
            get
            {
                return mYMin;
            }
            set
            {
                mYMin = value;
            }
        }

        public double YIncr
        {
            get
            {
                return mYIncr;
            }
            set
            {
                mYIncr = value;
            }
        }
    }
}
