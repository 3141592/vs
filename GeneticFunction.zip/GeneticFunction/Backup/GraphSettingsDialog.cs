using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace logistics
{
    public partial class GraphSettingsDialog : Form
    {
        public GraphSettingsDialog(GraphSettings settings)
        {
            InitializeComponent();

            this.textBoxSlopeColorLimit.Text = settings.SlopeColorLimit.ToString();
            this.textBoxBaseB.Text = settings.BaseB.ToString();
            this.textBoxBaseG.Text = settings.BaseG.ToString();
            this.textBoxBaseR.Text = settings.BaseR.ToString();

            this.textBoxFunction.Text = settings.Function.ToString();
            this.textBoxFunction.Text = settings.Function.ToString();
            this.textBoxFunction.Text = settings.Function.ToString();

            this.textBoxTraceLen.Text = settings.TraceLen.ToString();
            this.textBoxxIncr.Text = settings.XIncr.ToString();
            this.textBoxxMax.Text = settings.XMax.ToString();
            this.textBoxxMin.Text = settings.XMin.ToString();

            this.textBoxyIncr.Text = settings.YIncr.ToString();
            this.textBoxyMax.Text = settings.YMax.ToString();
            this.textBoxyMin.Text = settings.YMin.ToString();

        }

        private void GraphSettings_Load(object sender, EventArgs e)
        {
           
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonApply_Click(object sender, EventArgs e)
        {

        }
    }
}