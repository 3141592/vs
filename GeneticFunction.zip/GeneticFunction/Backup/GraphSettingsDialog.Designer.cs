namespace logistics
{
    partial class GraphSettingsDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonClose = new System.Windows.Forms.Button();
            this.buttonApply = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxFunction = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxxMin = new System.Windows.Forms.TextBox();
            this.textBoxxMax = new System.Windows.Forms.TextBox();
            this.textBoxxIncr = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxyIncr = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxyMax = new System.Windows.Forms.TextBox();
            this.textBoxyMin = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxTraceLen = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxSlopeColorLimit = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxBaseB = new System.Windows.Forms.TextBox();
            this.textBoxBaseG = new System.Windows.Forms.TextBox();
            this.textBoxBaseR = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.radioButtonFunction = new System.Windows.Forms.RadioButton();
            this.radioButtonSlope = new System.Windows.Forms.RadioButton();
            this.radioButtonDerivative = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // buttonClose
            // 
            this.buttonClose.Location = new System.Drawing.Point(211, 219);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(75, 23);
            this.buttonClose.TabIndex = 0;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // buttonApply
            // 
            this.buttonApply.Location = new System.Drawing.Point(130, 219);
            this.buttonApply.Name = "buttonApply";
            this.buttonApply.Size = new System.Drawing.Size(75, 23);
            this.buttonApply.TabIndex = 1;
            this.buttonApply.Text = "Apply";
            this.buttonApply.UseVisualStyleBackColor = true;
            this.buttonApply.Click += new System.EventHandler(this.buttonApply_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Function:";
            // 
            // textBoxFunction
            // 
            this.textBoxFunction.Location = new System.Drawing.Point(87, 11);
            this.textBoxFunction.Name = "textBoxFunction";
            this.textBoxFunction.Size = new System.Drawing.Size(199, 20);
            this.textBoxFunction.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "x Min/Max";
            // 
            // textBoxxMin
            // 
            this.textBoxxMin.Location = new System.Drawing.Point(87, 61);
            this.textBoxxMin.Name = "textBoxxMin";
            this.textBoxxMin.Size = new System.Drawing.Size(42, 20);
            this.textBoxxMin.TabIndex = 3;
            this.textBoxxMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxxMax
            // 
            this.textBoxxMax.Location = new System.Drawing.Point(135, 61);
            this.textBoxxMax.Name = "textBoxxMax";
            this.textBoxxMax.Size = new System.Drawing.Size(42, 20);
            this.textBoxxMax.TabIndex = 4;
            this.textBoxxMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxxIncr
            // 
            this.textBoxxIncr.Location = new System.Drawing.Point(223, 61);
            this.textBoxxIncr.Name = "textBoxxIncr";
            this.textBoxxIncr.Size = new System.Drawing.Size(42, 20);
            this.textBoxxIncr.TabIndex = 6;
            this.textBoxxIncr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(184, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "x Incr";
            // 
            // textBoxyIncr
            // 
            this.textBoxyIncr.Location = new System.Drawing.Point(223, 87);
            this.textBoxyIncr.Name = "textBoxyIncr";
            this.textBoxyIncr.Size = new System.Drawing.Size(42, 20);
            this.textBoxyIncr.TabIndex = 11;
            this.textBoxyIncr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(184, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "y Incr";
            // 
            // textBoxyMax
            // 
            this.textBoxyMax.Location = new System.Drawing.Point(135, 87);
            this.textBoxyMax.Name = "textBoxyMax";
            this.textBoxyMax.Size = new System.Drawing.Size(42, 20);
            this.textBoxyMax.TabIndex = 9;
            this.textBoxyMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxyMin
            // 
            this.textBoxyMin.Location = new System.Drawing.Point(87, 87);
            this.textBoxyMin.Name = "textBoxyMin";
            this.textBoxyMin.Size = new System.Drawing.Size(42, 20);
            this.textBoxyMin.TabIndex = 8;
            this.textBoxyMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "y Min/Max";
            // 
            // textBoxTraceLen
            // 
            this.textBoxTraceLen.Location = new System.Drawing.Point(87, 113);
            this.textBoxTraceLen.Name = "textBoxTraceLen";
            this.textBoxTraceLen.Size = new System.Drawing.Size(42, 20);
            this.textBoxTraceLen.TabIndex = 13;
            this.textBoxTraceLen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 116);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Trace Length";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 141);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Slope Colors";
            // 
            // textBoxSlopeColorLimit
            // 
            this.textBoxSlopeColorLimit.Location = new System.Drawing.Point(87, 158);
            this.textBoxSlopeColorLimit.Name = "textBoxSlopeColorLimit";
            this.textBoxSlopeColorLimit.Size = new System.Drawing.Size(42, 20);
            this.textBoxSlopeColorLimit.TabIndex = 16;
            this.textBoxSlopeColorLimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(53, 161);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(28, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Limit";
            // 
            // textBoxBaseB
            // 
            this.textBoxBaseB.Location = new System.Drawing.Point(183, 184);
            this.textBoxBaseB.Name = "textBoxBaseB";
            this.textBoxBaseB.Size = new System.Drawing.Size(42, 20);
            this.textBoxBaseB.TabIndex = 21;
            this.textBoxBaseB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxBaseG
            // 
            this.textBoxBaseG.Location = new System.Drawing.Point(135, 184);
            this.textBoxBaseG.Name = "textBoxBaseG";
            this.textBoxBaseG.Size = new System.Drawing.Size(42, 20);
            this.textBoxBaseG.TabIndex = 19;
            this.textBoxBaseG.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxBaseR
            // 
            this.textBoxBaseR.Location = new System.Drawing.Point(87, 184);
            this.textBoxBaseR.Name = "textBoxBaseR";
            this.textBoxBaseR.Size = new System.Drawing.Size(42, 20);
            this.textBoxBaseR.TabIndex = 18;
            this.textBoxBaseR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(24, 187);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "Base RGB";
            // 
            // radioButtonFunction
            // 
            this.radioButtonFunction.AutoSize = true;
            this.radioButtonFunction.Location = new System.Drawing.Point(87, 38);
            this.radioButtonFunction.Name = "radioButtonFunction";
            this.radioButtonFunction.Size = new System.Drawing.Size(66, 17);
            this.radioButtonFunction.TabIndex = 22;
            this.radioButtonFunction.TabStop = true;
            this.radioButtonFunction.Text = "Function";
            this.radioButtonFunction.UseVisualStyleBackColor = true;
            // 
            // radioButtonSlope
            // 
            this.radioButtonSlope.AutoSize = true;
            this.radioButtonSlope.Location = new System.Drawing.Point(155, 38);
            this.radioButtonSlope.Name = "radioButtonSlope";
            this.radioButtonSlope.Size = new System.Drawing.Size(52, 17);
            this.radioButtonSlope.TabIndex = 23;
            this.radioButtonSlope.TabStop = true;
            this.radioButtonSlope.Text = "Slope";
            this.radioButtonSlope.UseVisualStyleBackColor = true;
            // 
            // radioButtonDerivative
            // 
            this.radioButtonDerivative.AutoSize = true;
            this.radioButtonDerivative.Location = new System.Drawing.Point(213, 38);
            this.radioButtonDerivative.Name = "radioButtonDerivative";
            this.radioButtonDerivative.Size = new System.Drawing.Size(73, 17);
            this.radioButtonDerivative.TabIndex = 24;
            this.radioButtonDerivative.TabStop = true;
            this.radioButtonDerivative.Text = "Derivative";
            this.radioButtonDerivative.UseVisualStyleBackColor = true;
            // 
            // GraphSettingsDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(306, 250);
            this.Controls.Add(this.radioButtonDerivative);
            this.Controls.Add(this.radioButtonSlope);
            this.Controls.Add(this.radioButtonFunction);
            this.Controls.Add(this.textBoxBaseB);
            this.Controls.Add(this.textBoxBaseG);
            this.Controls.Add(this.textBoxBaseR);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textBoxSlopeColorLimit);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBoxTraceLen);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBoxyIncr);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxyMax);
            this.Controls.Add(this.textBoxyMin);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBoxxIncr);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxxMax);
            this.Controls.Add(this.textBoxxMin);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxFunction);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonApply);
            this.Controls.Add(this.buttonClose);
            this.Name = "GraphSettingsDialog";
            this.Text = "Settings";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.GraphSettings_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.Button buttonApply;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxFunction;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxxMin;
        private System.Windows.Forms.TextBox textBoxxMax;
        private System.Windows.Forms.TextBox textBoxxIncr;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxyIncr;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxyMax;
        private System.Windows.Forms.TextBox textBoxyMin;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxTraceLen;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxSlopeColorLimit;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxBaseB;
        private System.Windows.Forms.TextBox textBoxBaseG;
        private System.Windows.Forms.TextBox textBoxBaseR;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RadioButton radioButtonFunction;
        private System.Windows.Forms.RadioButton radioButtonSlope;
        private System.Windows.Forms.RadioButton radioButtonDerivative;
    }
}