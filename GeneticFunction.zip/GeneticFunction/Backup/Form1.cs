using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using ZedGraph;

namespace logistics
{
    public partial class Form1 : Form
    {
        public GraphSettings grSettings = new GraphSettings(); 

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            grSettings.XMin = -2;
            grSettings.XMax = 2;
            grSettings.XIncr = 0.1;

            grSettings.YMin = -2;
            grSettings.YMax = 2;
            grSettings.YIncr = 0.1;

            grSettings.Function = "cos(x)^2 + sin(x)^2";
            grSettings.Slope = "cos(x)^2 + sin(x)^2";
            grSettings.Derivative = "cos(x)^2 + sin(x)^2";

            grSettings.SlopeColorLimit = 2;
            grSettings.BaseR = 182;
            grSettings.BaseG = 182;
            grSettings.BaseB = 182;



            CreateGraph(zedGraphControl1);
            SetSize();

        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            SetSize();
        }

        private void SetSize()
        {
            zedGraphControl1.Location = new Point(12, 28);
            zedGraphControl1.Size = new Size(ClientRectangle.Width - 20, ClientRectangle.Height - 45);
        }

        private void CreateGraph(ZedGraphControl zgc)
        {
            GraphPane myPane = zgc.GraphPane;

            // Set the Titles
            myPane.Title.Text = "y' = y^2 - x";
            myPane.Chart.Fill.Type = FillType.Solid;
            myPane.Chart.Fill.Color = Color.Black;

            // Make up some data arrays based on the Sine function
            double x, y, y1, y2, y3;
            PointPairList list;
            PointPairList list1 = new PointPairList();
            PointPairList list2 = new PointPairList();
            PointPairList list3 = new PointPairList();
            LineItem myCurve;

            //  y' = y^2 - x
            for (x = grSettings.XMin; x <= grSettings.XMax; x = x + grSettings.XIncr)
            {
                for (y = grSettings.YMin; y <= grSettings.YMax; y = y + grSettings.YIncr)
                {
                    y1 = slope(x, y);

                    y2 = y1 + 0.1 * y1;
                    y3 = y1 - 0.1 * y1;

                    list = new PointPairList();
                    //list.Add(x - 0.01, y3);
                    //list.Add(x + 0.01, y2);
                    list.Add(x , y);

                    //myCurve = myPane.AddCurve("", list, SlopeColor(y1), SymbolType.None);
                    myCurve = myPane.AddCurve("", list, SlopeColor(y1), SymbolType.Default);
                    myCurve.Symbol.Size = 1;
                }
            }

            // Tell ZedGraph to refigure the axes since the data have changed
            zgc.AxisChange();
        }

        private Color SlopeColor(double slope)
        {
            // Create a green color using the FromRgb static method.
            Color myRgbColor = new Color();
            int R = 0;
            int G = 0;
            int B = 0;

            Random rnd = new Random();
            byte[] rgb = new byte[3];
            rnd.NextBytes(rgb);

            if (slope <= -grSettings.SlopeColorLimit)
            {
                R = Convert.ToInt32(255 * (-grSettings.SlopeColorLimit / slope));
                G = Convert.ToInt32(255 * (-grSettings.SlopeColorLimit / slope));
                B = Convert.ToInt32(255 * (-grSettings.SlopeColorLimit / slope));

                G = grSettings.BaseG;
                B = grSettings.BaseB;
            }
            else if (slope <= grSettings.SlopeColorLimit)
            {
                R = Convert.ToInt32((255 / (2 * grSettings.SlopeColorLimit)) * slope + (255 / 2));
                G = Convert.ToInt32((255 / (2 * grSettings.SlopeColorLimit)) * slope + (255 / 2));
                B = Convert.ToInt32((255 / (2 * grSettings.SlopeColorLimit)) * slope + (255 / 2));

                R = grSettings.BaseR;
                B = grSettings.BaseB;
            }
            else if (slope > grSettings.SlopeColorLimit)
            {
                R = Convert.ToInt32(255 * (grSettings.SlopeColorLimit / slope));
                G = Convert.ToInt32(255 * (grSettings.SlopeColorLimit / slope));
                B = Convert.ToInt32(255 * (grSettings.SlopeColorLimit / slope));

                G = grSettings.BaseG;
                R = grSettings.BaseR;
            }
            myRgbColor = Color.FromArgb(R, G, B);
            return myRgbColor;
        }

        private double slope(double x0, double y0)
        {
            return Math.Pow(Math.Cos(x0), 2) + Math.Pow(Math.Sin(y0),2);
        }

        private double function( double x0 )
        {
            return 2 * Math.Pow(x0, 4) + 2 * Math.Pow(x0, 3) + 2 * x0 + 3; 
        }

        private double derivative(double x0)
        {
            return 8 * Math.Pow(x0, 3) + 6 * Math.Pow(x0, 2) + 2;
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                //Application.Run(new Form1());
                GraphSettingsDialog settings = new GraphSettingsDialog(grSettings);
                settings.Show();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GraphSettingsDialog settings = new GraphSettingsDialog(grSettings);
            settings.Show();
        }
           
    }
}