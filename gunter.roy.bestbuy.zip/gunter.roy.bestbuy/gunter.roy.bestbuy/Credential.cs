﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gunter.roy.bestbuy

{
    public class Credential
    {
        public string CredentialName { get; set; }
        public string UserName { get; set; }
        public string Key { get; set; }
    }
}
